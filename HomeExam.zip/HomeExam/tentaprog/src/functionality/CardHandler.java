package functionality;

import cards.*;

import java.lang.reflect.Array;
import java.util.*;

/**
 * Handles and creates the deck and discard-deck.
 * @author Claude
 */

public class CardHandler {
    private ArrayList<Card> deck;
    private ArrayList<Card> discard;
    private static CardHandler instance;


    private CardHandler(){
        this.deck = new ArrayList<Card>();
        this.discard = new ArrayList<Card>();

    }

    public void createDeck(int numPlayers, boolean insertExplKitten){
        if(insertExplKitten == false){
            for(int i=0; i<4; i++){
                deck.add(new AttackCard());
                deck.add(new FavorCard());
                deck.add(new ShuffleCard());
                deck.add(new SkipCard());
                deck.add(new HairyPotatoCatCard());
                deck.add(new CatterMelonCard());
                deck.add(new RainBowRalphingCatCard());
                deck.add(new TacoCatCard());
                deck.add(new OverweightBikiniCatCard());
            }
            for(int i=0; i<5; i++){
                deck.add(new SeeTheFutureCard());
                deck.add(new NopeCard());
            }
            if(numPlayers == 2 || numPlayers == 3){
                deck.add(new DefuseCard());
                deck.add(new DefuseCard());
                
            }
            else{
                for(int i=0; i<6-numPlayers; i++){
                    deck.add(new DefuseCard());
                }
            }

        } else{
            for(int i=0; i<numPlayers-1; i++){
                deck.add(new ExplodingKittenCard());
            }
        }
    }


    public void dealCards(){
        for(Player player : PlayerHandler.getInstance().getPlayers()){
            player.getHand().add(new DefuseCard());
            for(int i=0; i<7; i++) {
                player.getHand().add(this.deck.remove(0));}
        }
    }

    public ArrayList<Card> getDeck(){
        return this.deck;
    }

    public static ArrayList<Card> getDiscard(){
        return getInstance().discard;

    }
    public static CardHandler getInstance(){
        if(instance == null){
            instance = new CardHandler();
        }
        return instance;
    }

    public ArrayList<String> checkIfTwo(){
        ArrayList<Card> hand = PlayerHandler.getCurrentPlayer().getHand();
        ArrayList<String> temp = new ArrayList<String>();
        HashMap<String, Integer> two = new HashMap<String, Integer>();
        ArrayList<String> returnTwo = new ArrayList<String>();
        for(Card card : hand){
            temp.add(card.getCardType());
        }
        for(String cardType : temp){
            two.put(cardType, Collections.frequency(temp, cardType));
        }
        for(String i : two.keySet()){
            if(two.get(i) == 2){
                returnTwo.add(i);
            }
        }
        return returnTwo;
    }
    public ArrayList<String> checkIfThree(){
        ArrayList<Card> hand = PlayerHandler.getCurrentPlayer().getHand();
        ArrayList<String> temp = new ArrayList<String>();
        HashMap<String, Integer> Three = new HashMap<String, Integer>();
        ArrayList<String> returnThree = new ArrayList<String>();
        for(Card card : hand){
            temp.add(card.getCardType());
        }
        for(String cardType : temp){
            Three.put(cardType, Collections.frequency(temp, cardType));
        }
        for(String i : Three.keySet()){
            if(Three.get(i) == 3){
                returnThree.add(i);
            }
        }
        return returnThree;
    }


}
