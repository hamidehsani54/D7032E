package functionality;

import cards.Card;

import java.util.*;
import java.io.*;
import java.net.*;

/**
 * Creates player-objects which store information that is
 * essential for the game, thus a lot of getters and setters.
 * @author Claude
 */
public class Player{
    private int secondsToInterruptWithNope = 5;
    Scanner in = new Scanner(System.in);
    private int playerID;
    private boolean online;
    private boolean isBot;
    private Socket connection;
    private boolean exploded = false;
    private ObjectInputStream inFromClient;
    private ObjectOutputStream outToClient;
    private ArrayList<Card> hand = new ArrayList<Card>();
    private int turnAmount = 1;


    public Player(int playerID, boolean isBot, Socket connection, ObjectInputStream inFromClient, ObjectOutputStream outToClient) {
        this.playerID = playerID;
        this.connection = connection;
        this.inFromClient = inFromClient;
        this.outToClient = outToClient;
        this.isBot = isBot;


        if(connection == null)
            this.online = false;
        else
            this.online = true;
    }

    public void setTurnAmount(int turnAmount){
        this.turnAmount = turnAmount;
    }

    public int getTurnAmount(){
        return this.turnAmount;
    }

    public boolean getOnline(){
        return this.online;
    }

    public int getPlayerID(){
        return this.playerID;
    }

    public ObjectInputStream getInFromClient() {
        return inFromClient;
    }

    public ObjectOutputStream getOutToClient(){
        return outToClient;
    }

    public boolean getIsBot() {
        return isBot;
    }

    public ArrayList<Card> getHand(){
        return this.hand;
    }

    public boolean getExploded(){
        return this.exploded;
    }

    public void setExploded(boolean exploded){
        this.exploded = exploded;
    }

    public void removeSpecFromHand(String cardType){
        for(int i=0; i<this.hand.size(); i++){
            if(Objects.equals(this.hand.get(i).getCardType(), cardType)) this.hand.remove(i);
        }
    }

    public boolean doesCardExist(String cardType){
        for(int i=0; i<this.hand.size(); i++){
            if(Objects.equals(this.hand.get(i).getCardType(), cardType)) return true;
        }
        return false;
    }

    public void discardCards(String cardType){
        for(int i=0; i<getHand().size();){
            if(Objects.equals(getHand().get(i).getCardType(), cardType)){
                CardHandler.getDiscard().add(getHand().remove(i));
            }
        }
    }

    public Card getSpecCard(String cardType){
        Card returnCard = null;
        for(Card cards : PlayerHandler.getCurrentPlayer().getHand()){
            if(Objects.equals(cards.getCardType(), cardType)) returnCard = cards;
        }
        return returnCard;
    }

    public void drawCard(){
        this.getHand().add(CardHandler.getInstance().getDeck().remove(0));
    }

    public void sendMessage(Object message) {
        if(this.getOnline()) {
            try {this.getOutToClient().writeObject(message);} catch (Exception e) {}
        } else if(!this.getIsBot()){
            System.out.println(message);
        }
    }
    public String readMessage(boolean interruptable) {
        String word = " ";
        if(this.getOnline())
            try{
                word = (String) this.getInFromClient().readObject();
            } catch (Exception e){
                System.out.println("Reading from client failed: " + e.getMessage());
            }
        else
            try {
                if(interruptable) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                    int millisecondsWaited = 0;
                    while(!br.ready() && millisecondsWaited<(secondsToInterruptWithNope*1000)) {
                        Thread.sleep(200);
                        millisecondsWaited += 200;
                    }
                    if(br.ready())
                        return br.readLine();
                } else {
                    in = new Scanner(System.in);
                    word=in.nextLine();
                }
            } catch(Exception e){System.out.println(e.getMessage());}
        return word;
    }
}