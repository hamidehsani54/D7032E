package functionality;


import java.io.*;
import java.net.*;

/**
 * Calls methods to create players.
 * Opens up a socket and connects objects to these which players can send and read from
 * @author Our teacher Josef Hallberg
 */

public class Server {
    static ServerSocket aSocket;


    public static void server(int numberPlayers, int numberOfBots, PlayerHandler playerHandler) throws Exception {
        //Player 0
        playerHandler.populatePlayerHandler(false, null, null, null);
        for(int i=0; i<numberOfBots; i++) {
            playerHandler.botulatePlayerHandler(true, null, null, null);
        }
        if(numberPlayers>1)
            aSocket = new ServerSocket(2048);
        for(int i=numberOfBots+1; i<numberPlayers+numberOfBots; i++) {
            Socket connectionSocket = aSocket.accept();
            ObjectInputStream inFromClient = new ObjectInputStream(connectionSocket.getInputStream());
            ObjectOutputStream outToClient = new ObjectOutputStream(connectionSocket.getOutputStream());
            playerHandler.populatePlayerHandler(false, connectionSocket, inFromClient, outToClient);
            System.out.println("Connected to player " + i);
            outToClient.writeObject("You connected to the server as player " + i + "\n");
        }
    }



}