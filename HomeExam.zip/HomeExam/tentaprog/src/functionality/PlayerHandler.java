package functionality;

import java.util.*;
import java.io.*;
import java.net.*;

/**
 * Handles amount of players and keeps track of them.
 * Handles which players turn it is.
 * @author Claude
 */

public class PlayerHandler {
    private ArrayList<Player> players;
    private ArrayList<Player> turn;
    private int id = 0;
    private static PlayerHandler instance;

    private PlayerHandler(){
        this.players = new ArrayList<Player>();
        this.turn = new ArrayList<Player>();
    }


    public void populatePlayerHandler(boolean isBot, Socket connection, ObjectInputStream inFromClient, ObjectOutputStream outToClient){
        boolean b = (id < 1) ? this.players.add(new Player(0, false, null, null, null)) : this.players.add(new Player(id, isBot, connection, inFromClient, outToClient));
        id++;
    }


    public void botulatePlayerHandler(boolean isBot, Socket connection, ObjectInputStream inFromClient, ObjectOutputStream outToClient){
        this.players.add(new Player(id, isBot, connection, inFromClient, outToClient));
        id++;
    }

    public void initRandomTurn(){
        turn = this.players;
        Collections.shuffle(turn);
        }

    public static void changeTurn(){
        Player temp = instance.turn.get(0);
        instance.turn.remove(0);
        instance.turn.add(temp);
        }

    public ArrayList<Player> getTurn(){
        return getInstance().turn;
    }

    public ArrayList<Player> getPlayers(){
        return getInstance().players;
    }

    public static Player getCurrentPlayer(){
        Player currentPlayer = getInstance().turn.get(0);
        return currentPlayer;
        }

    //singleton
    public static PlayerHandler getInstance() {
        if(instance == null){
            instance = new PlayerHandler();
        }
        return instance;
    }
}