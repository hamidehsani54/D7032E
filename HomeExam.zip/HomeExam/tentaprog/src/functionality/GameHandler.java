package functionality;

import cards.Card;
import cards.FavorCard;
import cards.SeeTheFutureCard;


import java.util.*;

import java.util.concurrent.*;

/**
 * The class on top of the hierarchy.
 * One GameHandler object is created which has one CardHandler and one PlayerHandler object.
 * Starts server and client. Initializes the game.
 * Contains the game loop. Checks for nopes in different thread.
 * @author Claude
 */

public class GameHandler {
    CardHandler cardHandler;
    PlayerHandler playerHandler;
    public int secondsToInterruptWithNope = 5;

    public GameHandler(String[] params) throws Exception {
        cardHandler = CardHandler.getInstance();
        playerHandler = PlayerHandler.getInstance();


        if(params.length == 2) {
            this.initGame(Integer.valueOf(params[0]).intValue(), Integer.valueOf(params[1]).intValue());
        } else if(params.length == 1) {
            Client.client(params[0]);
        } else {
            System.out.println("Server syntax: java ExplodingKittens numPlayers numBots");
            System.out.println("Client syntax: IP");
        }
    }

    public static void main(String argv[]) {
        try {
            new GameHandler(argv);
        } catch(Exception e) {

        }
    }

    public void initGame(int numPlayers, int numBots) {
        try {
            //start up server. Connect players to socket.
            Server.server(numPlayers, numBots, playerHandler);
            playerHandler.initRandomTurn();
            cardHandler.createDeck(numPlayers, false);
            System.out.println(cardHandler.getDeck().size());
            Collections.shuffle(cardHandler.getDeck());
            cardHandler.dealCards();
            cardHandler.createDeck(numPlayers, true);
            System.out.println(PlayerHandler.getCurrentPlayer().getHand().size());
            Collections.shuffle(cardHandler.getDeck());
            gameLoop();

        } catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void gameLoop() throws Exception {
        Player currentPlayer = PlayerHandler.getCurrentPlayer();
        int playersLeft = PlayerHandler.getInstance().getPlayers().size();
        do {
            String otherPlayerIDs = "PlayerID: ";
            for (Player player : PlayerHandler.getInstance().getPlayers()) {
                if (player.getPlayerID() != currentPlayer.getPlayerID()) otherPlayerIDs += player.getPlayerID() + " ";
                if (player == PlayerHandler.getCurrentPlayer())
                    player.sendMessage("It is your turn");
                else
                    player.sendMessage("It is now the turn of player" + currentPlayer.getPlayerID());
            }

            String response = "";
            while (!response.equalsIgnoreCase("Pass")) {

                currentPlayer.sendMessage("\nYou have " + currentPlayer.getTurnAmount() + ((currentPlayer.getTurnAmount() > 1) ? " turns " : " turn ") + " to take");
                String yourHand = "";
                for(int i=0; i < currentPlayer.getHand().size()-1; i++){
                    yourHand += currentPlayer.getHand().get(i).getCardType() + " ";
                }
                currentPlayer.sendMessage("Your hand: " + yourHand);

                String yourOptions = "You have the following options:\n";
                ArrayList<String> cardsWithFreqTwo = CardHandler.getInstance().checkIfTwo();
                ArrayList<String> cardsWithFreqThree = CardHandler.getInstance().checkIfThree();
                for(int i=0; i<cardsWithFreqTwo.size(); i++){
                    yourOptions += "\tTwo " + cardsWithFreqTwo.get(i) + " [target] (available targets: " + otherPlayerIDs + ") (Steal random card)\n";
                }
                for(int i=0; i<cardsWithFreqThree.size(); i++){
                    yourOptions += "\tThree " + cardsWithFreqThree.get(i) + " [target] [Card Type] (available targets: " + otherPlayerIDs + ") (Name and pick a card)\n";
                }

                for (int i=0; i <currentPlayer.getHand().size()-1; i++) {
                    if (currentPlayer.getHand().get(i).getCardType() == "AttackCard")
                        yourOptions += "\tAttack\n";
                    if (currentPlayer.getHand().get(i).getCardType() == "FavorCard")
                        yourOptions += "\tFavor [target] (available targets: " + otherPlayerIDs + ")\n";
                    if (currentPlayer.getHand().get(i).getCardType() == "ShuffleCard")
                        yourOptions += "\tShuffle\n";
                    if (currentPlayer.getHand().get(i).getCardType() == "SkipCard")
                        yourOptions += "\tSkip\n";
                    if (currentPlayer.getHand().get(i).getCardType() == "SeeTheFutureCard")
                        yourOptions += "\tSeeTheFuture\n";
                }
                yourOptions += "\tPass";
                currentPlayer.sendMessage(yourOptions);
                response = currentPlayer.readMessage(false);
                if (yourOptions.contains(response.replaceAll("\\d", ""))) {
                    if (response.equals("Pass")) {
                        currentPlayer.drawCard();
                        Card defuseCard = PlayerHandler.getCurrentPlayer().getSpecCard("DefuseCard");
                        defuseCard.cardEffect();
                        if(currentPlayer.getExploded() != true){
                            currentPlayer.drawCard();
                            currentPlayer.sendMessage("You drew: " + currentPlayer.getHand().get(currentPlayer.getHand().size()-1));
                        }
                    }
                    else if(response.contains("Two")) { //played 2 of a kind - steal random card from target player
                        String[] args = response.split(" ");
                        Card countCard = PlayerHandler.getCurrentPlayer().getSpecCard(args[1]);
                        int count = Collections.frequency(currentPlayer.getHand(), countCard);
                        if(count == 2) {
                            currentPlayer.discardCards(args[1]);
                            currentPlayer.discardCards(args[1]);
                            letPlayersUseTheirNope("Two of a kind against player " + args[2]);
                            if(checkNrNope() % 2 == 0) {
                                Player target = PlayerHandler.getInstance().getPlayers().get((Integer.valueOf(args[2])).intValue());
                                Random rnd = new Random();
                                Card aCard = target.getHand().remove(rnd.nextInt(target.getHand().size()-1));
                                currentPlayer.getHand().add(aCard);
                                target.sendMessage("You gave " + aCard + " to player " + currentPlayer.getPlayerID());
                                currentPlayer.sendMessage("You received " + aCard + " from player " + target.getPlayerID());
                            }
                        }

                    } else if(response.contains("Three")) { //played 3 of a kind - name a card and force target player to hand one over if they have it
                        String[] args = response.split(" ");
                        Card countCard = PlayerHandler.getCurrentPlayer().getSpecCard(args[1]);
                        int count = Collections.frequency(currentPlayer.getHand(), countCard);
                        if(count == 3) {
                            currentPlayer.discardCards(args[1]);
                            currentPlayer.discardCards(args[1]);
                            currentPlayer.discardCards(args[1]);
                            letPlayersUseTheirNope("Two of a kind against player " + args[2]);
                            if(checkNrNope() % 2 == 0) {
                                Player target = PlayerHandler.getInstance().getPlayers().get((Integer.valueOf(args[2])).intValue());
                                Card card = target.getSpecCard(args[3]);
                                Card targetCard = target.getSpecCard(card.getCardType());
                                if(target.doesCardExist(args[2])) {
                                    currentPlayer.getHand().add(targetCard);
                                    target.removeSpecFromHand(targetCard.getCardType());
                                    target.sendMessage("Player " + currentPlayer.getPlayerID() + " stole " + targetCard);
                                    currentPlayer.sendMessage("You received " + targetCard + " from player " + target.getPlayerID());
                                } else {
                                    currentPlayer.sendMessage("The player did not have any " + targetCard);
                                }
                            }
                        }
                    }
                    else if(response.equals("Attack")) {
                        letPlayersUseTheirNope("Attack");
                        if(checkNrNope() % 2 == 0) {
                            currentPlayer.getSpecCard("AttackCard").cardEffect();
                        }
                    }
                    else if(response.contains("Favor")) {
                        currentPlayer.discardCards("FavorCard");
                        String[] args = response.split(" ");
                        Player target = PlayerHandler.getInstance().getPlayers().get((Integer.valueOf(args[1])).intValue());
                        letPlayersUseTheirNope("Favor player " + target.getPlayerID());
                        if(checkNrNope() % 2 == 0) {
                            ((FavorCard)currentPlayer.getSpecCard("Favor")).favorCardEffect(target);
                        }
                    }
                    else if(response.equals("Shuffle")) {
                        currentPlayer.discardCards("ShuffleCard");
                        letPlayersUseTheirNope("Shuffle");
                        if(checkNrNope() % 2 == 0) {
                            currentPlayer.getSpecCard("ShuffleCard").cardEffect();
                        }
                    }
                    else if(response.equals("Skip")) {
                        currentPlayer.discardCards("SkipCard");
                        letPlayersUseTheirNope("Skip");
                        if(checkNrNope() % 2 == 0) {
                            currentPlayer.getSpecCard("SkipCard").cardEffect();
                        }
                    }
                    else if(response.equals("SeeTheFuture")) {
                        currentPlayer.discardCards("SeeTheFutureCard");
                        letPlayersUseTheirNope("SeeTheFutureCard");
                        if(checkNrNope() % 2 == 0) {
                            ((SeeTheFutureCard)currentPlayer.getSpecCard("SeeTheFutureCard")).seeTheFutureCardEffect();
                        }
                    }
                }
                else {
                    currentPlayer.sendMessage("Not a viable option, try again");
                }
            }

            do { //next player that is still in the game
                int nextID=((currentPlayer.getPlayerID()+1)<PlayerHandler.getInstance().getPlayers().size()?(currentPlayer.getPlayerID())+1:0);
                currentPlayer = PlayerHandler.getInstance().getPlayers().get(nextID);
                System.out.println("hej");
            } while(currentPlayer.getExploded() && playersLeft>1);

        } while(playersLeft>1);

        Player winner = currentPlayer;
        for(Player notify: PlayerHandler.getInstance().getPlayers())
            winner = (!notify.getExploded()?notify:winner);
        for(Player notify: PlayerHandler.getInstance().getPlayers())
            notify.sendMessage("Player " + winner.getPlayerID() + " has won the game");
        System.exit(0);
    }

    public void letPlayersUseTheirNope(String card) throws Exception {
        //After an interruptable card is played everyone has 5 seconds to play Nope
        int nopePlayed = checkNrNope();
        ExecutorService threadpool = Executors.newFixedThreadPool(PlayerHandler.getInstance().getPlayers().size());
        for(Player p : PlayerHandler.getInstance().getPlayers()) {
            p.sendMessage("Action: Player " + PlayerHandler.getCurrentPlayer().getPlayerID() + " played " + card);
            if(p.doesCardExist("nopeCard")) { //only give the option to interrupt to those who have a Nope card
                p.sendMessage("Press <Enter> to play Nope");
                Runnable task = new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String nextMessage = p.readMessage(true); //Read that is interrupted after secondsToInterruptWithNope
                            if(!nextMessage.equals(" ") && p.doesCardExist("NopeCard")) {
                                p.discardCards("NopeCard");
                                for(Player notify: PlayerHandler.getInstance().getPlayers())
                                    notify.sendMessage("Player " + p.getPlayerID() + " played Nope");
                            }
                        } catch(Exception e) {
                            System.out.println("addToDiscardPile: " +e.getMessage());
                        }
                    }
                };
                threadpool.execute(task);
            }
        }
        threadpool.awaitTermination((secondsToInterruptWithNope*1000)+500, TimeUnit.MILLISECONDS); //add an additional delay to avoid concurrancy problems with the ObjectInputStream
        for(Player notify: PlayerHandler.getInstance().getPlayers())
            notify.sendMessage("The timewindow to play Nope passed");
        if(checkNrNope()>nopePlayed) {
            for(Player notify: PlayerHandler.getInstance().getPlayers())
                notify.sendMessage("Play another Nope? (alternate between Nope and Yup)");
            letPlayersUseTheirNope(card);
        }
    }

    public int checkNrNope() {
        int i=0;
        ArrayList<Card> discard = CardHandler.getDiscard();
        while(i<CardHandler.getDiscard().size() && discard.get(discard.size()-1).getCardType()=="NopeCard") {
            i++;
        }
        return i;
    }
}

