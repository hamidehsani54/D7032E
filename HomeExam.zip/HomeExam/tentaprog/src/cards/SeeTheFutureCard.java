package cards;

import functionality.CardHandler;

import java.util.ArrayList;

public class SeeTheFutureCard implements Card{
    private String cardType;

    public SeeTheFutureCard(){
        this.cardType = "SeeTheFutureCard";
    }
    public void cardEffect() {}

    //@Override
    public String seeTheFutureCardEffect() {
        ArrayList<Card> deck = CardHandler.getInstance().getDeck();
        return "The top 3 cards are: " + deck.get(0) + " " + deck.get(1) + " " + deck.get(2);
    }

    public String getCardType(){
        return this.cardType;
    }
}
