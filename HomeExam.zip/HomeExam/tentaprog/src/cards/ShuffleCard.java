package cards;

import functionality.CardHandler;
import functionality.PlayerHandler;

import java.util.*;

public class ShuffleCard implements Card{
    private String cardType;

    public ShuffleCard(){
        this.cardType = "ShuffleCard";
    }

    public void cardEffect(){
        Collections.shuffle(CardHandler.getInstance().getDeck());
    }

    public String getCardType(){
        return this.cardType;
    }
}