package cards;

public class TacoCatCard implements Card{
    private String cardType;
    public TacoCatCard(){
        this.cardType = "TacoCatCard";
    }


    public void cardEffect(){}
    public String getCardType(){
        return this.cardType;
    }
}
