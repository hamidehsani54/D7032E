package cards;

public class NopeCard implements Card{
    private String cardType;
    public NopeCard(){
        this.cardType = "NopeCard";
    }


    public String getCardType(){
        return this.cardType;
    }

    public void cardEffect() {}
}
