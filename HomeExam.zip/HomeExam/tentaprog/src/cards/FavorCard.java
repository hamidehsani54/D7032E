package cards;

import functionality.Player;
import functionality.PlayerHandler;

public class FavorCard implements Card{
    private String cardType;

    public FavorCard(){
        this.cardType = "FavorCard";
    }

    @Override
    public void cardEffect() {}

    public void favorCardEffect(Player target) {
        boolean viableOption = false;
        if(target.getHand().size()==0)
            viableOption=true; //special case - target has no cards to give
        while(!viableOption) {
            target.sendMessage("Your hand: " + target.getHand());
            target.sendMessage("Give a card to Player " + PlayerHandler.getCurrentPlayer().getPlayerID());
            String tres = target.readMessage(false);
            if(target.doesCardExist(tres)) {
                viableOption = true;
                PlayerHandler.getCurrentPlayer().getHand().add(target.getSpecCard(tres));
                target.getHand().remove(target.getSpecCard(tres));
            } else {
                target.sendMessage("Not a viable option, try again");
            }
        }
    }


    public String getCardType(){
        return this.cardType;
    }

}
