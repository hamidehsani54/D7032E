package cards;

public class CatterMelonCard implements Card{
    private String cardType;
    public CatterMelonCard(){
        this.cardType = "CatterMelonCard";
    }

    public void cardEffect(){}

    public String getCardType(){
        return this.cardType;
    }

}
