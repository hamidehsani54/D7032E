package cards;

public class RainBowRalphingCatCard implements Card{
    private String cardType;
    public RainBowRalphingCatCard(){
        this.cardType = "RainBowRalphingCatCard";
    }

    public void cardEffect(){}

    public String getCardType(){
        return this.cardType;
    }
}
