package cards;

/**
 * Cards that carry out effects on other players.
 * @author Claude
 */

public interface Card {
    public abstract void cardEffect();
    public abstract String getCardType();

}