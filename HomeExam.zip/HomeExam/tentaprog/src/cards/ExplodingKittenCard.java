package cards;

import functionality.CardHandler;
import functionality.PlayerHandler;

public class ExplodingKittenCard implements Card{
    private String cardType;
    public ExplodingKittenCard(){
        this.cardType = "ExplodingKittenCard";
    }

    public void cardEffect(){
        //discard all cards on hand
        for(int i = 0; i < PlayerHandler.getCurrentPlayer().getHand().size(); i++){
            CardHandler.getInstance().getDiscard().add(PlayerHandler.getCurrentPlayer().getHand().get(i));
            PlayerHandler.getCurrentPlayer().getHand().clear();
        }
        PlayerHandler.getCurrentPlayer().setExploded(true);
        //PlayerHandler.getInstance().getPlayers().remove(PlayerHandler.getCurrentPlayer());
    }

    public String getCardType(){
        return this.cardType;
    }

}
