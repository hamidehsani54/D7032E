package cards;

import functionality.PlayerHandler;

public class SkipCard implements Card{

    private String cardType;

    public SkipCard(){
        this.cardType = "SkipCard";
    }
    //@Override
    public void cardEffect() {
        if(PlayerHandler.getCurrentPlayer().getTurnAmount() == 2){
            PlayerHandler.getCurrentPlayer().setTurnAmount(1);
        } else PlayerHandler.changeTurn();
    }

    public String getCardType(){
        return this.cardType;
    }
}
