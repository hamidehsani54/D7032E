package cards;

public class OverweightBikiniCatCard implements Card{
    private String cardType;
    public OverweightBikiniCatCard(){
        this.cardType = "OverweightBikiniCatCard";
    }

    public void cardEffect(){}

    public String getCardType(){
        return this.cardType;
    }
}
