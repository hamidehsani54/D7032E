package cards;

import functionality.CardHandler;
import functionality.Player;
import functionality.PlayerHandler;

public class DefuseCard implements Card{
    private String cardType;
    public DefuseCard(){
        this.cardType = "DefuseCard";
    }

    public void cardEffect(){
        Card instOfExplodingKitten = PlayerHandler.getCurrentPlayer().getSpecCard("ExplodingKittenCard");
        if(instOfExplodingKitten != null){
            if(PlayerHandler.getCurrentPlayer().doesCardExist("DefuseCard")){
                Card defuseCard = PlayerHandler.getCurrentPlayer().getSpecCard("DefuseCard");
                PlayerHandler.getCurrentPlayer().removeSpecFromHand("DefuseCard");
                PlayerHandler.getCurrentPlayer().sendMessage("You defused the kitten. Where in the deck do you wish to place the ExplodingKitten? [0.." + (PlayerHandler.getCurrentPlayer().getHand().size()-1) + "]");
                CardHandler.getInstance().getDeck().add((Integer.valueOf(PlayerHandler.getCurrentPlayer().readMessage(false))).intValue(), defuseCard);
                for(Player p : PlayerHandler.getInstance().getPlayers()) {
                    p.sendMessage("Player " + PlayerHandler.getCurrentPlayer().getPlayerID() + " successfully defused a kitten");
                }
            } else instOfExplodingKitten.cardEffect();
        }
    }

    public String getCardType(){
        return this.cardType;
    }
}
