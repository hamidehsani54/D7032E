package cards;

public class HairyPotatoCatCard implements Card{
    private String cardType;
    public HairyPotatoCatCard(){
        this.cardType = "HairyPotatoCatCard";
    }

    public void cardEffect(){}

    public String getCardType(){
        return this.cardType;
    }

}
