package cards;

import functionality.CardHandler;
import functionality.PlayerHandler;

public class AttackCard implements Card {

    private String cardType;

    public AttackCard(){
        this.cardType = "AttackCard";
    }
    //@Override
    public void cardEffect(){
        PlayerHandler.getInstance().getTurn().get(1).setTurnAmount(2);
        PlayerHandler.changeTurn();

    }
    public String getCardType(){
        return this.cardType;
    }

}